package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 5000; i++) {
            for (int j = 0; j < 2000; j++) {
                for (int k = 0; k < 1000; k++) {
                    for (int l = 0; l < 500; l++) {
                        for (int m = 0; m < 200; m++) {
                            System.out.println(i);

                        }

                    }

                }

            }

        }
    }
}
